package app;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class GestorUsuarios {
    private JPanel panel1;                      // root panel (vinculado al .form)
    private JPanel headerWrapperPanel;
    private JPanel west;
    private JButton dashboardButton;
    private JButton ayudaButton;
    private JButton ajustesButton;
    private JButton informesButton;
    private JButton usuariosButton;
    private JTextField textField1;              // Nombre
    private JTextField textField2;              // Email
    private JComboBox comboBox1;                // Rol
    private JCheckBox checkBox1;                // Activo
    private JTabbedPane tabbedPane1;
    private JTextArea resumenAreaTextArea;
    private JTextArea logsareaTextArea;
    private JButton cancelarButton;
    private JButton limpiarButton;
    private JButton guardarButton;

    public GestorUsuarios() {
        // Inicializar combo si no se hizo desde el .form
        if (comboBox1 != null && comboBox1.getItemCount() == 0) {
            comboBox1.addItem("Admin");
            comboBox1.addItem("Editor");
            comboBox1.addItem("Invitado");
        }

        // Asegurarnos de que las áreas de texto existan
        if (resumenAreaTextArea != null) {
            resumenAreaTextArea.setEditable(false);
            resumenAreaTextArea.setLineWrap(true);
            resumenAreaTextArea.setWrapStyleWord(true);
        }
        if (logsareaTextArea != null) {
            logsareaTextArea.setEditable(false);
            logsareaTextArea.setLineWrap(true);
            logsareaTextArea.setWrapStyleWord(true);
        }

        // Listeners botones
        if (limpiarButton != null) {
            limpiarButton.addActionListener(e -> limpiarCampos());
        }

        if (cancelarButton != null) {
            cancelarButton.addActionListener(e -> {
                Window w = SwingUtilities.getWindowAncestor(panel1);
                if (w != null) w.dispose();
            });
        }

        if (guardarButton != null) {
            guardarButton.addActionListener(e -> {
                // abrir diálogo modal de confirmación
                DialogConfirmacion dialog = new DialogConfirmacion(getFrame());
                dialog.pack();
                dialog.setLocationRelativeTo(panel1);
                dialog.setVisible(true); // modal
                if (dialog.isConfirmed()) {
                    guardarSimulado();
                }
            });
        }

        // Ejemplo: acciones de navegación (solo visual)
        if (dashboardButton != null) {
            dashboardButton.addActionListener(e -> JOptionPane.showMessageDialog(panel1, "Ir a Dashboard (simulado)"));
        }
        if (usuariosButton != null) {
            usuariosButton.addActionListener(e -> JOptionPane.showMessageDialog(panel1, "Ir a Usuarios (simulado)"));
        }
        if (informesButton != null) {
            informesButton.addActionListener(e -> JOptionPane.showMessageDialog(panel1, "Ir a Informes (simulado)"));
        }
        if (ajustesButton != null) {
            ajustesButton.addActionListener(e -> JOptionPane.showMessageDialog(panel1, "Ir a Ajustes (simulado)"));
        }
        if (ayudaButton != null) {
            ayudaButton.addActionListener(e -> JOptionPane.showMessageDialog(panel1, "Ayuda (simulada)"));
        }
    }

    private JFrame getFrame() {
        Window w = SwingUtilities.getWindowAncestor(panel1);
        if (w instanceof JFrame) return (JFrame) w;
        // crear un frame temporal si no existe (rara vez pasa)
        JFrame f = new JFrame("Gestor de usuarios");
        f.setContentPane(panel1);
        f.pack();
        return f;
    }

    private void limpiarCampos() {
        if (textField1 != null) textField1.setText("");
        if (textField2 != null) textField2.setText("");
        if (comboBox1 != null) comboBox1.setSelectedIndex(0);
        if (checkBox1 != null) checkBox1.setSelected(false);
        if (resumenAreaTextArea != null) resumenAreaTextArea.setText("");
        // logs los dejamos
    }

    private void guardarSimulado() {
        String nombre = textField1 != null ? textField1.getText().trim() : "";
        String email = textField2 != null ? textField2.getText().trim() : "";
        String rol = (comboBox1 != null && comboBox1.getSelectedItem() != null) ? comboBox1.getSelectedItem().toString() : "";
        boolean activo = checkBox1 != null && checkBox1.isSelected();
        String notas = ""; // si hay un campo de notas distinto, ajusta el nombre
        // Componer resumen
        StringBuilder sb = new StringBuilder();
        sb.append("Nombre: ").append(nombre).append("\n");
        sb.append("Email: ").append(email).append("\n");
        sb.append("Rol: ").append(rol).append("\n");
        sb.append("Activo: ").append(activo).append("\n");
        sb.append("\nNotas:\n");
        sb.append(notas);

        if (resumenAreaTextArea != null) resumenAreaTextArea.setText(sb.toString());
        if (logsareaTextArea != null) {
            logsareaTextArea.append(String.format("[%s] Guardado usuario: %s <%s>%n", nowTimestamp(), nombre, email));
        }

        JOptionPane.showMessageDialog(panel1, "Guardado (simulación)");
    }

    private String nowTimestamp() {
        return java.time.LocalDateTime.now().toString();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            // Si el .form está vinculado y los nombres coinciden, este constructor usará panel1 del form.
            GestorUsuarios gui = new GestorUsuarios();
            JFrame frame = new JFrame("Gestor de usuarios");
            frame.setContentPane(gui.panel1);
            frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            frame.pack();
            // Centrar y establecer botón por defecto si existe
            frame.setLocationRelativeTo(null);
            try {
                if (gui.guardarButton != null) frame.getRootPane().setDefaultButton(gui.guardarButton);
            } catch (Exception ignored) {}
            // Añadir protección para cerrar el diálogo correctamente
            frame.addWindowListener(new WindowAdapter() {
                @Override
                public void windowClosing(WindowEvent e) {
                    // por si hay procesos que cerrar más adelante
                }
            });
            frame.setVisible(true);
        });
    }

    /**
     * Diálogo de confirmación simple (modal)
     */
    private static class DialogConfirmacion extends JDialog {
        private boolean confirmed = false;

        DialogConfirmacion(Window owner) {
            super(owner, "Confirmación", ModalityType.APPLICATION_MODAL);
            initUI();
        }

        private void initUI() {
            JPanel content = new JPanel(new BorderLayout(8,8));
            content.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
            JLabel label = new JLabel("¿Guardar cambios?");
            content.add(label, BorderLayout.CENTER);

            JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
            JButton aceptar = new JButton("Aceptar");
            JButton cancelar = new JButton("Cancelar");
            buttons.add(cancelar);
            buttons.add(aceptar);
            content.add(buttons, BorderLayout.SOUTH);

            aceptar.addActionListener(e -> {
                confirmed = true;
                dispose();
            });
            cancelar.addActionListener(e -> {
                confirmed = false;
                dispose();
            });

            setContentPane(content);
            getRootPane().setDefaultButton(aceptar);
            pack();
            setResizable(false);
        }

        public boolean isConfirmed() {
            return confirmed;
        }
    }
}


package app;

public class GestorUsuariosForm {
    public static void main(String[] args) {
        // Llama al main existente de GestorUsuarios
        GestorUsuarios.main(args);
    }
}
